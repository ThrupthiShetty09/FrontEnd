import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MainpageComponent}  from './mainpage/mainpage.component';
import  {LoginComponent} from './c_login/login.component'
import  {b_LoginComponent} from './b_login/login.component'

import  {TermsComponent} from './terms/terms.component';
import  {MdupdateComponent} from './mdupdate/mdupdate.component';
import  {ManagerComponent} from './manager/manager.component';
import  {MRegistrationComponent} from './m-registration/m-registration.component';
import  {FaqComponent} from './faq/faq.component';
import {CustomerComponent} from './customer/customer.component';
import {DashboardComponent} from './dashboard/dashboard.component';

import {ApproveloanComponent} from './c_agentmain/approveloan/approveloan.component'
import {AgentcomponentComponent} from './c_agentmain/c_agentcomponent/agentcomponent.component'
import {AgentprofileComponent} from './c_agentmain/c_agentprofile/agentprofile.component'
import {ApproveCustComponent} from './c_agentmain/c_approve-cust/approve-cust.component'
import {ViewcustomerComponent} from './c_agentmain/c_viewcustomer/viewcustomer.component'
import {ViewtransactionComponent} from './c_agentmain/c_viewtransaction/viewtransaction.component'
import {AgentmainComponent} from './c_agentmain/agentmain.component'
import {CustomerProfileComponent} from './customer-profile/customer-profile.component'

import {AgentregistrationComponent} from './b_agentregistration/agentregistration.component'
const routes: Routes = [
{ path:'',redirectTo:'mainpage',pathMatch:'full'},
 { path:'mainpage', component:MainpageComponent },
 { path:'regform', component:AgentregistrationComponent},
 {path:'c_login',component:LoginComponent},
  {path:'b_login',component:b_LoginComponent},

 {path:'approveloan',component:ApproveloanComponent},
 {path:'c_agentcomponent',component:AgentcomponentComponent},
 {path:'c_agentprofile',component:AgentprofileComponent},
 {path:'c_approve-cust',component:ApproveCustComponent},
 {path:'c_viewcustomer',component:ViewcustomerComponent},
 {path:'c_viewtransaction',component:ViewtransactionComponent},
 {path:'c_agentmain',component:AgentmainComponent},
 {path:'customer-profile',component:CustomerProfileComponent},
 { path:'dashboard', component:DashboardComponent },
 { path:'customer',component:CustomerComponent},
 { path:'manager',component:ManagerComponent},
 { path:'m-registration',component:MRegistrationComponent},
 {path:'mdupdate',component:MdupdateComponent},
 {path:'faq',component:FaqComponent},
 {path:'terms',component:TermsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }