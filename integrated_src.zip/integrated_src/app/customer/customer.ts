export class Customer{
	public cust_id:number;
	public name:string;
	public dob:Date;
	public contact:number;
	public address:string;
	public username:string;
	public password:string;
	public aadhar_card:number;
	public pan_card:string;
	public branch_id:string;
	public customer_Acc_no:number;
	public open_date:Date;
	public balance:number;
	public account_id:string;

	constructor( cust_id:number, name:string, dob:Date, contact:number, address:string,username:string,password:string, aadhar_card:number, pan_card:string, branch_id:string, customer_Acc_no:number,open_date:Date, balance:number, account_id:string)
{
	this.cust_id=cust_id;
	this.name=name;
	this.dob=dob;
	this.contact=contact;
	this.address=address;
	this.username=username;
	this.password=password;
	this.aadhar_card=aadhar_card;
	this.pan_card=pan_card;
	this.branch_id=branch_id;
	this.customer_Acc_no=customer_Acc_no;
	this.open_date=open_date;
	this.balance=balance;
	this.account_id=account_id;
}
}

