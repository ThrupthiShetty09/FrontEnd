import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgentregistrationserviceService } from './agentregistrationservice.service'
import { Agent } from './agent';
import  {FormsModule,FormGroup,FormControl,Validators,FormBuilder} from '@angular/forms'

@Component({
  selector: 'app-agentregistration',
  templateUrl: './agentregistration.component.html',
  styleUrls: ['./agentregistration.component.css']
})
export class AgentregistrationComponent implements OnInit {

   name:string;
   dob:string;
   contact:number;
   address:string;
   username:string;
   password:string;
   aadhar_card:number;
   pan_card:string;
   branch_id:string;

	agent:Agent;
	submitted=false;
   /*   registerForm: FormGroup;*/

/*
  form=new FormGroup({

    name:new FormControl('',Validators.required)
  })*/
	
  model: any = new Agent('','',0,'','','',0,'','');

constructor(private router:Router, private agentregService: AgentregistrationserviceService) { 
(function() {
  'use strict';
  window.addEventListener('load', function() {

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();

}

  ngOnInit() {

/*     this.registerForm = this.formBuilder.group({
            name: ['', Validators.required],
       
        });*/
    }


  
  createAgent(){
  	this.submitted=true;
  	this.save();
    alert("Registered successfully");
this.router.navigate(['mainpage']);
  }

  save(){

  	this.name=this.model.name;
    console.log(this.name);
  	this.dob=this.model.dob;
    console.log(this.dob);
  	this.contact=this.model.contact;
    this.address=this.model.address;
  	this.username=this.model.username;
  	this.password=this.model.password;
    this.aadhar_card=this.model.aadhar_card;
    this.pan_card=this.model.pan_card;
  	this.branch_id=this.model.branch_id;
    this.agent=new Agent(this.name,this.dob,this.contact,this.address,this.username,this.password,this.aadhar_card,this.pan_card,this.branch_id);
  
    this.agentregService.createAgent(this.agent).subscribe(data=>console.log(data),error=>console.log(error));

  	//this.router.navigate(['agentdashboard']);
  }
   
/*  agentregistration()
{
	this.router.navigate(['/agentregistration']);
}

*/
}
