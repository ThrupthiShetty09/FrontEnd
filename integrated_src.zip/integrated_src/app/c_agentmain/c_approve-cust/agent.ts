

export class Agent{
	private accno:number;
	private  name:string;
	private dob:string;
	
	private contact:number;
	
	private address:string;
	private amount:number;
	private branch:string;
	private open_date:string;
	private loan_type:string;
	private aadhar_card:number;
	private pan_card:string;
	private acc_type:string;
	private action:string; 
	constructor(accno,name,dob,contact,address,amount,branch,open_date,aadhar_card,pan_card,acc_type,action)
	{
		this.accno=accno;
		this.name=name;
		this.dob=dob;
		this.contact=contact;
		this.address=address;
		this.amount=amount;
	
		this.branch=branch;
		this.open_date=open_date;

		
		this.aadhar_card=aadhar_card;
		this.pan_card=pan_card;
		this.acc_type=acc_type;
		this.action=action;
		

	}
	
}
