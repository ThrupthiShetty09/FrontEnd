import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AllCommunityModules} from '@ag-grid-community/all-modules';
import {HttpClient} from '@angular/common/http';
import { LoanserviceService } from './loanservice.service';
import {Loan} from './loan';

@Component({
  selector: 'app-approveloan',
  templateUrl: './approveloan.component.html',
  styleUrls: ['./approveloan.component.css']
})
export class ApproveloanComponent implements OnInit {

columnDefs=[
 {headerName: 'Loan Account Number', field: 'loan_Acc_no',width:100,  sortable: true, filter: true,checkboxSelection:true },
        {headerName: 'Loan Type', field: 'loan_type',width:100, sortable: true, filter: true},
         {headerName: 'Customer Account Number', field: 'custoner_Acc_no',width:80,  sortable: true, filter: true},
        {headerName: 'Customer Name', field: 'name',width:100,  sortable: true, filter: true },
        {headerName: 'Open Date', field: 'open_date',width:100,  sortable: true, filter: true},
       {headerName: 'Balance', field: 'balance',width:100,  sortable: true, filter: true},
      
             {headerName: 'Branch Name', field: 'branch_name',width:100,  sortable: true, filter: true },
               {headerName: 'Approval', field: 'approval',width:100,  sortable: true, filter: true },
           

       
       
      
        
    ];

       
     rowData: any;

    modules = AllCommunityModules;
id:string;
  constructor(private router: Router,private _httpService: LoanserviceService,private http: HttpClient) { 

  }

  ngOnInit() {
 this.id = localStorage.getItem('token');
    this.rowData = this.http.get('http://localhost:8090/cust_project/c_loan/'+this.id);
     this._httpService.getloandetails(this.id).subscribe((res:any[])=>{
       console.log(res);
       this.getData=res;
      
});

  }
  private gridApi;
  private gridColumnsApi;


  getData:any;
  loan:Loan;
approved()
{
   this._httpService.getCustomerDetails(this.id).subscribe((res:any[])=>{
       console.log(res);
       this.getData=res;
       this.router.navigate(['c_approve']);
});
 }

  main1()
  {
              this.router.navigate(['c_agentmain']);

  }

  logout()
  {
    this.router.navigate(['c_login']);
  }
  onGridReady(params)
  {
    this.gridApi=params.api;
    this.gridColumnsApi=params.columnApi;
  }
  activate()
  {

   var selecteddata=this.gridApi.getSelectedRows();
     console.log(selecteddata[0].loan_Acc_no);
     //console.log(selecteddata[0].balance);
     // console.log(this.loan);
    this.loan=new Loan(selecteddata[0].loan_Acc_no,selecteddata[0].balance,selecteddata[0].open_date,"Approve",selecteddata[0].loan_type,selecteddata[0].name,selecteddata[0].custoner_Acc_no,selecteddata[0].branch_name);
     //console.log(this.loan);
      this._httpService.updateloan(this.loan,selecteddata[0].loan_Acc_no).subscribe(data=>console.log(data),error=>console.log(error));   
       this.id = localStorage.getItem('token');
    console.log(this.id);
   
    
     //this.rowData = this.http.get('http://localhost:8042/c_myproject/c_customer/'+this.id);
     location.reload();
     
  }
  deactivate()
  {
   
   var selecteddata=this.gridApi.getSelectedRows();
     console.log(selecteddata[0].loan_Acc_no);
     //console.log(selecteddata[0].balance);
     // console.log(this.loan);
    this.loan=new Loan(selecteddata[0].loan_Acc_no,selecteddata[0].balance,selecteddata[0].open_date,"Disapprove",selecteddata[0].loan_type,selecteddata[0].name,selecteddata[0].custoner_Acc_no,selecteddata[0].branch_name);
     //console.log(this.loan);
      this._httpService.updateloan(this.loan,selecteddata[0].loan_Acc_no).subscribe(data=>console.log(data),error=>console.log(error));   
       this.id = localStorage.getItem('token');
    console.log(this.id);
   
    
     //this.rowData = this.http.get('http://localhost:8042/c_myproject/c_customer/'+this.id);
     location.reload();
  }
}

