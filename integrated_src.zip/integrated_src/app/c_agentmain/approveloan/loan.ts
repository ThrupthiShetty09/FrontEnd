	export class Loan
	{
	private loan_Acc_no:string;
	private  balance:number;
	private open_date:string;
	private  approval:string;
	private  loan_type:string;
	private name:string;
	private  custoner_Acc_no:number;
	private branch_name:string;
	constructor(loan_Acc_no,balance,open_date,approval,loan_type,name,custoner_Acc_no,branch_name)
	{
		this.loan_Acc_no=loan_Acc_no;
		this.open_date=open_date;
		this.balance=balance;
		this.approval=approval;
		this.loan_type=loan_type;
		this.name=name;
		this.custoner_Acc_no=custoner_Acc_no;
		this.branch_name=branch_name;
	}
}
