export class Employee {
	private empid:string;
	private empname:string;

	private empdob:string;
	private empcontact:number;
	private empmail:string;
	private empbranch:string;
	private username:string;
	private password:string;

	
	constructor(id,name,dob,contact,mail,branch) {
		this.empid=id;
		this.empname=name;
		
		this.empdob=dob;
		this.empcontact=contact;
		this.empmail=mail;
		this.empbranch=branch;
		
		
	}
}
