import { Component, OnInit } from '@angular/core';
import {AllCommunityModules} from '@ag-grid-community/all-modules';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {Agent} from '../c_approve-cust/agent';

@Component({
  selector: 'app-viewcustomer',
  templateUrl: './viewcustomer.component.html',
  styleUrls: ['./viewcustomer.component.css']
})
export class ViewcustomerComponent implements OnInit {

/*let gridDiv = document.querySelector('#myGrid');

        var gridOptions ={
*/
	columnDefs=[
        {headerName: 'Account Number', field: 'accno',width:100, sortable: true, filter: true,checkboxSelection:true },
         {headerName: 'Name', field: 'name',width:100,  sortable: true, filter: true},
            {headerName: 'DOB', field: 'dob', sortable: true,width:100,  filter: true },
              {headerName: 'Contact', field: 'contact', sortable: true,width:100,  filter: true },
        {headerName: 'Address', field: 'address',width:100,  sortable: true, filter: true },
         
       {headerName: 'Balance', field: 'amount', sortable: true,width:80,  filter: true},
     
             {headerName: 'Open Date', field: 'open_date', sortable: true,width:100,  filter: true },
              {headerName: 'Branch', field: 'branch', sortable: true,width:100,  filter: true },
             {headerName: 'Loan_type', field: 'loan_type',width:100,  sortable: true, filter: true },
          {headerName: 'Aadhar Card', field: 'aadhar_card', sortable: true,width:100,  filter: true },
                {headerName: 'PanCard', field: 'pan_card',width:100,  sortable: true, filter: true },
                 {headerName: 'Approval', field: 'action', width:100, sortable: true, filter: true },
                  
      
    
      
     
       
       
      
        
    ];


     rowData: any;

    modules = AllCommunityModules;


  private gridApi;
  private gridColumnsApi;
    onGridReady(params)
  {
    this.gridApi=params.api;
    this.gridColumnsApi=params.columnApi;
  }
  constructor(private router: Router,private http: HttpClient) { }
 id: string;
  ngOnInit() {
    this.id = localStorage.getItem('token');
    console.log(this.id);
   
    
     this.rowData = this.http.get('http://localhost:8090/cust_project/c_customer/'+this.id);
  }
  main1()
  {
              this.router.navigate(['c_agentmain']);

  }
  
  logout()
  {
    this.router.navigate(['c_login']);
  }
  Profile2()

  {
          var selecteddata=this.gridApi.getSelectedRows();
         /* Agent a=new Agent(selecteddata[0].accno,selecteddata[0].name,selecteddata[0].dob,selecteddata[0].contact,selecteddata[0].address);*/
        this.router.navigate(['customer-profile',{id:selecteddata[0].accno}]);

  }
}



