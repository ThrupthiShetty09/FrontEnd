import { TestBed } from '@angular/core/testing';

import { CustprofileService } from './custprofile.service';

describe('CustprofileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustprofileService = TestBed.get(CustprofileService);
    expect(service).toBeTruthy();
  });
});
